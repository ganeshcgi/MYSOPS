#!/bin/bash

# Update package lists
apt update

# Upgrade packages
apt upgrade -y
apt install firewalld -y
apt install -y chrony resolvconf  vim 
systemctl restart firewalld
touch /opt/Server_Setup.log
echo " firewalld service has been restrated " >> /opt/Server_Setup.log

systemctl enable firewalld
systemctl restart chrony

systemctl enable chrony


firewall-cmd --permanent --add-port=22/tcp
#firewall-cmd --permanent --add-port=80/tcp
#firewall-cmd --permanent --add-port=443/tcp
firewall-cmd --reload

# Create groups

groupadd Admins
echo " Admins group Created " >> /opt/Server_Setup.log
groupadd Developers
echo " Developers group Created " >> /opt/Server_Setup.log

# Create users and add them to groups
useradd -c naresh -m -d  /home/naresh -s /bin/bash naresh
echo " naresh user Created " >> /opt/Server_Setup.log
useradd -c gururaj -m -d  /home/gururaj -s /bin/bash gururaj
echo " gururaj user Created " >> /opt/Server_Setup.log
useradd -c srvacc -m -d  /home/srvacc -s /bin/bash srvacc
echo " srvacc user Created " >> /opt/Server_Setup.log



gpasswd -M naresh,gururaj,ubuntu,srvacc Admins
echo " naresh,srvacc,gururaj,ubuntu users has been added to the Admins group " >> /opt/Server_Setup.log

# Create .ssh directory in home directories
mkdir -p /home/naresh/.ssh
echo " .ssh directory has been created on /home/naresh/ " >> /opt/Server_Setup.log
mkdir -p /home/gururaj/.ssh
echo " .ssh directory has been created on /home/gururaj/ " >> /opt/Server_Setup.log
mkdir -p /home/srvacc/.ssh
echo " .ssh directory has been created on /home/srvacc/ " >> /opt/Server_Setup.log


# Create authorized_keys file in .ssh directories

touch /home/naresh/.ssh/authorized_keys
echo " authorized_keys file has been created on /home/naresh/ " >> /opt/Server_Setup.log
touch /home/gururaj/.ssh/authorized_keys
echo " authorized_keys file has been created on /home/gururaj/ " >> /opt/Server_Setup.log
touch /home/srvacc/.ssh/authorized_keys
echo " authorized_keys file has been created on /home/srvacc/ " >> /opt/Server_Setup.log


# Set permissions for .ssh directory
chown -R naresh:naresh /home/naresh
chown -R gururaj:gururaj /home/gururaj
chown -R srvacc:srvacc /home/srvacc

echo " naresh,srvacc,gururaj user home directory ownership has been changed " >> /opt/Server_Setup.log

chmod 700 /home/naresh/.ssh
chmod 700 /home/gururaj/.ssh
chmod 700 /home/srvacc/.ssh


echo " naresh,servacc,gururaj users .ssh directory permissions has been changed to 700 " >> /opt/Server_Setup.log

chmod 600 /home/naresh/.ssh/authorized_keys
chmod 600 /home/gururaj/.ssh/authorized_keys
chmod 600 /home/srvacc/.ssh/authorized_keys

echo " naresh,srvacc,gururaj users authorized_keys file permissions has been changed to 600 " >> /opt/Server_Setup.log

#systemctl stop cloud-config.service cloud-final.service cloud-init-hotplugd.socket cloud-init.service cloud-config.target cloud-init-hotplugd.service cloud-init-local.service cloud-init.target
#systemctl disable --now cloud-config.service cloud-final.service cloud-init-hotplugd.socket cloud-init.service cloud-config.target cloud-init-hotplugd.service cloud-init-local.service cloud-init.target

#echo " cloud services has been stoped and disabled " >> /opt/Server_Setup.log

# Backup the original sshd_config file
cp /etc/ssh/sshd_config /etc/ssh/sshd_config_backup

echo " sshd_config file has been taken backup " >> /opt/Server_Setup.log

# Add AllowGroups Admins and Developers to sshd_config file
echo "AllowGroups Admins Developers" >> /etc/ssh/sshd_config
echo "PubkeyAcceptedKeytypes=+ssh-rsa" >> /etc/ssh/sshd_config

echo " AllowGroups and PubkeyAcceptedKeytypes has been added " >> /opt/Server_Setup.log

# Restart SSH service to apply the changes
service ssh restart

echo " ssh service restarted " >> /opt/Server_Setup.log

# Uncomment the lines that match the specified pattern
sed -i '/^#LoginGraceTime/s/^#//' /etc/ssh/sshd_config
sed -i '/^#StrictModes/s/^#//' /etc/ssh/sshd_config
sed -i '/^#SyslogFacility/s/^#//' /etc/ssh/sshd_config
sed -i '/^#LogLevel/s/^#//' /etc/ssh/sshd_config
sed -i '/^#MaxAuthTries/s/^#//' /etc/ssh/sshd_config
sed -i '/^#MaxSessions/s/^#//' /etc/ssh/sshd_config
sed -i '/^#AuthorizedKeysFile/s/^#//' /etc/ssh/sshd_config

echo " ssh perameters has been uncommented " >> /opt/Server_Setup.log



# Uncomment and replace the value of the PermitRootLogin setting
sed -i 's/#PermitRootLogin prohibit-password/PermitRootLogin no/' /etc/ssh/sshd_config

echo " PermitRootLogin set to no " >> /opt/Server_Setup.log

# Uncomment and replace the value of the PasswordAuthentication setting
sed -i 's/#PasswordAuthentication yes/PasswordAuthentication no/' /etc/ssh/sshd_config

echo " PasswordAuthentication set to no " >> /opt/Server_Setup.log


# Restart SSH service to apply the changes
sudo systemctl restart ssh
sudo systemctl enable ssh
# Backup the original /etc/bash.bashrc file
cp /etc/bash.bashrc /etc/bash.bashrc_backup

# Add the specified lines to the /etc/bash.bashrc file
echo 'PS1="\[\033[1;31m\][\u@\[\033[34m\]\h \W]# \[\033[0m\]"' >> /etc/bash.bashrc
echo 'export EDITOR="vim"' >> /etc/bash.bashrc
echo 'export HISTTIMEFORMAT="%d/%m/%y %T "' >> /etc/bash.bashrc
echo 'export HISTSIZE=100000' >> /etc/bash.bashrc
echo 'export HISEFILESIZE=100000' >> /etc/bash.bashrc

# Backup the original /etc/sudoers file
cp /etc/sudoers /etc/sudoers_backup

# Comment the specified lines in the /etc/sudoers file
sed -i '/^%admin/s/^/#/' /etc/sudoers
sed -i '/^%sudo/s/^/#/' /etc/sudoers
# Add the specified lines to the /etc/sudoers file
echo '%Admins ALL=(ALL) NOPASSWD:ALL' >> /etc/sudoers
echo '%Developers ALL=(ALL) NOPASSWD:ALL' >> /etc/sudoers

# Backup the original /etc/chrony/chrony.conf file
cp /etc/chrony/chrony.conf /etc/chrony/chrony.conf_backup

# Comment out the specified lines in the /etc/chrony/chrony.conf file
#sed -i '/^pool ntp.ubuntu.com/s/^/#/' /etc/chrony/chrony.conf
#sed -i '/^pool 0.ubuntu.pool.ntp.org/s/^/#/' /etc/chrony/chrony.conf
#sed -i '/^pool 1.ubuntu.pool.ntp.org/s/^/#/' /etc/chrony/chrony.conf
#sed -i '/^pool 2.ubuntu.pool.ntp.org/s/^/#/' /etc/chrony/chrony.conf

# Add the specified line to the /etc/chrony/chrony.conf file
#echo "pool 172.16.2.171 iburst" >> /etc/chrony/chrony.conf

echo "ssh-rsa AAAAB3NzaC1yc2EAAAABJQAAAQEAhTGC38v2RMFBsK14Bllt51PsW2e1uh7PQ2prTk1ZJ3Zz5eT55mAebVBai36jz8SbH8X+hhWc7IEQqRMdSbsq+bph8sHj00qqOMLr7TeY981tjK+7mPebUWX3zUP/g63Nx3xsfxu5FPnsxA0WAYDgUQ9vpZ+pH+Q21Cy0nxat05sUx8owKll1a3H3wHeo4Mz6KQvrvB9oEnLSMIj4X+9M3dvakDd8/C8tJpfRUOOlv6XqYzo67JSfNLboRGJ/GXCVNtQoSU+To+sen/hxKBBs6UonqzPdieHUHCGxZf1bkGf2HGqrR8pGGovnhR2djLAsyC8wvtsjO5dH6xvmSrbHtw== rsa-key-20220528" >> /home/naresh/.ssh/authorized_keys
echo "ssh-rsa AAAAB3NzaC1yc2EAAAABJQAAAQEA0QqQ/STEc8GghFcck071TXuMIYtAo0xjGEU/nggDU9T3ZA5uSubYGpDj2lYtjEHtWC8+dlO+8fCoXu5ho2+XoYNyy9E+/3DD8nDa0qwxODfU8CKMvKFfV0xDnvLMCeI4s01g/wPKypYCI8b7oligjSu93Iiw3h3oV5KH3mC4/Bw2DojaLWpMlqRmiya+WF18/BFuDmrxEB3EMbR3UnxkILFhrYLgEgrrbenKJuui3goLapPqgBr+L3C/9mroQUrRR43Hje83Vh+MFVo6hwxMvRg3l/ZtzUR6GTiaGa/kAryUxzc5jN7GmUJP36VRe8fJ7A0mwfSp6wAlGJZlvcVtrQ== rsa-key-20220528" >> /home/gururaj/.ssh/authorized_keys
echo "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCCHJAYVY2th7i3D2biYomKohAzj+nkQDi688ZR9qprbP4+u32FTQhzJgBlt2Maev9f8bRbLDAnOyfb1DJt3SCuDdJHaU/YJf+EidVuYPjaKLzXF5DOO600dG/oEjJvo3toqT0J+DgxNuPNSNgCTE2k7ASA7W4chGJbXQ2uW+gcZovv4Lru73AvLUqh/Iaz93cVUEHHfgCt2FDm+xENAZcyLRRmeeAa8X2I/X5fjoK0lwbaZJCssJGZwXkTGwS/WgMiF3bJVXbphg1igz7/Z+aWp2VePeufcOjrZnAZ++AJeW1zmQJKBdD39WH5Vm+7hK/szZOFXZdCCVA2EkYCjyT/ rsa-key-20240919" >> /home/srvacc/.ssh/authorized_keys
sudo systemctl restart sshd
sudo systemctl enable sshd